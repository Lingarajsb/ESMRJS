import React, { Component } from 'react'  
  
export class Footer extends Component {  
    render() {  
        return (  
            <div>  
                 <footer class="sticky-footer bg-white">  
        <div class="container my-auto">  
          <div class="copyright text-center my-auto">  
            <span>Copyright © Your Website 2019</span>  
          </div>  
        </div>  
      </footer>  
            </div>  
        )  
    }  
}  
  
export default Footer  